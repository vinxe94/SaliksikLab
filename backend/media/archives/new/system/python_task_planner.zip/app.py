"""Daybreak: Flask API, private SQLite workspaces, and a bundled frontend."""
import hashlib, hmac, json, math, os, re, secrets, sqlite3, time
from datetime import date
from pathlib import Path
from flask import Flask, request, jsonify, g, send_from_directory
from werkzeug.exceptions import HTTPException
from waitress import serve

ROOT = Path(__file__).resolve().parent
C = json.loads((ROOT / 'config.json').read_text())
TABLE, KEYS = C['entity'], [f['key'] for f in C['fields']]
DB_PATH = Path(os.environ.get('HOSTING_DB_PATH') or os.environ.get('DATABASE_PATH') or ROOT / 'data/app.sqlite3')
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
with sqlite3.connect(DB_PATH) as db:
    db.executescript((ROOT / 'schema.sql').read_text())
    db.execute('CREATE TABLE IF NOT EXISTS auth_attempts (ip TEXT PRIMARY KEY, hits INTEGER NOT NULL, until INTEGER NOT NULL)')
app = Flask(__name__, static_folder=None)
app.config['MAX_CONTENT_LENGTH'] = 24576

class APIError(Exception):
    def __init__(self, status, message): self.status, self.message = status, message

def database():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db

@app.teardown_appcontext
def close_db(error):
    if 'db' in g: g.db.close()

def body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict): raise APIError(400, 'Send a valid JSON object.')
    return data

def clean(data):
    result = {}
    for f in C['fields']:
        v = data.get(f['key'], '' if not f['required'] else None)
        if f['type'] == 'number':
            if isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v) or not f['min'] <= v <= f['max'] or (f.get('integer') and int(v) != v):
                raise APIError(400, f['label'] + ' is outside its allowed range.')
        else:
            if not isinstance(v, str): raise APIError(400, f['label'] + ' must be text.')
            v = v.strip()
            if (f['required'] and not v) or len(v) > (2000 if f['type'] == 'textarea' else 200): raise APIError(400, 'Please check ' + f['label'] + '.')
            if f['type'] == 'select' and v not in f['options']: raise APIError(400, 'Invalid ' + f['label'] + '.')
            if f['type'] == 'date':
                try:
                    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', v) or not '1900-01-01' <= v <= '2100-12-31': raise ValueError()
                    date.fromisoformat(v)
                except ValueError: raise APIError(400, 'Enter a valid date.')
            if f['type'] == 'email' and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', v): raise APIError(400, 'Enter a valid email.')
            if f['type'] == 'time' and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d', v): raise APIError(400, 'Enter a valid time.')
        result[f['key']] = v
    return result

def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    key = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1, dklen=32).hex()
    return salt + ':' + key

def insert(uid, values):
    return database().execute(f'INSERT INTO {TABLE} (user_id,{",".join(KEYS)}) VALUES ({",".join("?" for _ in range(len(KEYS)+1))})', [uid, *[values[k] for k in KEYS]]).lastrowid

def session(uid):
    token = secrets.token_hex(32)
    database().execute('DELETE FROM sessions WHERE expires < ?', (int(time.time()),))
    database().execute('INSERT INTO sessions VALUES (?,?,?)', (hashlib.sha256(token.encode()).hexdigest(), uid, int(time.time())+43200))
    return token

@app.before_request
def authenticate():
    if request.path.startswith('/api/') and request.path not in ['/api/auth/login', '/api/auth/register']:
        token = request.headers.get('Authorization', '').removeprefix('Bearer ')
        g.token_hash = hashlib.sha256(token.encode()).hexdigest()
        g.user = database().execute('SELECT users.id,users.name,users.email FROM sessions JOIN users ON users.id=sessions.user_id WHERE token_hash=? AND expires>?', (g.token_hash, int(time.time()))).fetchone() if re.fullmatch(r'[a-f0-9]{64}', token) else None
        if not g.user: raise APIError(401, 'Please sign in. Your session may have expired.')

@app.after_request
def headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'same-origin'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'"
    if request.path.startswith('/api/'): response.headers['Cache-Control'] = 'no-store'
    return response

@app.errorhandler(Exception)
def failure(error):
    if isinstance(error, APIError): return jsonify(error=error.message), error.status
    if isinstance(error, HTTPException): return jsonify(error=error.description), error.code
    app.logger.exception('Request failed')
    return jsonify(error='The server could not complete the request.'), 500

@app.post('/api/auth/<action>')
def auth(action):
    if action == 'logout':
        with database(): database().execute('DELETE FROM sessions WHERE token_hash=?', (g.token_hash,))
        return jsonify(ok=True)
    if action not in ['login','register']: raise APIError(404, 'Endpoint not found.')
    db=database(); now=int(time.time()); ip=request.remote_addr
    with db:
        db.execute('DELETE FROM auth_attempts WHERE until < ?', (now,))
        db.execute('INSERT INTO auth_attempts VALUES (?,1,?) ON CONFLICT(ip) DO UPDATE SET hits=hits+1', (ip, now+300))
    if db.execute('SELECT hits FROM auth_attempts WHERE ip=?', (ip,)).fetchone()[0] > 60: raise APIError(429, 'Too many attempts. Please try again in five minutes.')
    data=body(); email=data.get('email'); password=data.get('password')
    email=email.strip().lower() if isinstance(email,str) else ''
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or len(email)>254 or not isinstance(password,str) or not 10<=len(password)<=128: raise APIError(400, 'Use a valid email and a password of 10–128 characters.')
    user=db.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
    if action=='register':
        name=data.get('name')
        if not isinstance(name,str) or not 1<=len(name.strip())<=80: raise APIError(400, 'Enter a name of 1–80 characters.')
        if user: raise APIError(409, 'An account with this email already exists.')
        ph=password_hash(password)
        try:
            with db:
                uid=db.execute('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)',(name.strip(),email,ph)).lastrowid
                for seed in C['seeds']: insert(uid,clean(seed))
                token=session(uid)
                user=db.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
        except sqlite3.IntegrityError: raise APIError(409, 'An account with this email already exists.')
    else:
        if not user or not hmac.compare_digest(password_hash(password,user['password_hash'].split(':')[0]), user['password_hash']): raise APIError(401, 'Email or password is incorrect.')
        with db: token=session(user['id'])
    return jsonify(token=token,user={k:user[k] for k in ['id','name','email']}), 201 if action=='register' else 200

@app.get('/api/auth/me')
def me(): return jsonify(user=dict(g.user))

def record(row): return {k:row[k] for k in row.keys() if k!='user_id'}

@app.route('/api/records',methods=['GET','POST'])
def collection():
    if request.method=='GET': return jsonify(records=[record(r) for r in database().execute(f'SELECT * FROM {TABLE} WHERE user_id=? ORDER BY id DESC',(g.user['id'],))])
    data=clean(body())
    with database(): uid=insert(g.user['id'],data)
    return jsonify(record={'id':uid,**data}),201

@app.route('/api/records/<int:uid>',methods=['GET','PUT','DELETE'])
def item(uid):
    found=database().execute(f'SELECT * FROM {TABLE} WHERE id=? AND user_id=?',(uid,g.user['id'])).fetchone()
    if not found: raise APIError(404,'Record not found.')
    if request.method=='GET': return jsonify(record=record(found))
    with database():
        if request.method=='DELETE': database().execute(f'DELETE FROM {TABLE} WHERE id=? AND user_id=?',(uid,g.user['id']))
        else:
            data=clean(body())
            database().execute(f'UPDATE {TABLE} SET {",".join(k+"=?" for k in KEYS)} WHERE id=? AND user_id=?', [*[data[k] for k in KEYS],uid,g.user['id']])
    return jsonify(ok=True) if request.method=='DELETE' else jsonify(record={'id':uid,**data})

@app.get('/')
def index(): return send_from_directory(ROOT/'public','index.html')

@app.get('/assets/<path:filename>')
def assets(filename): return send_from_directory(ROOT/'public/assets', filename)

if __name__=='__main__': serve(app,host='0.0.0.0',port=int(os.environ.get('PORT','8080')),threads=4,max_request_body_size=24576)
