# Hands on final

Workspace initialized from Collaboration Hub.
